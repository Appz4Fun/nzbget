#ifndef NZBGET_CRYPTOREAD_H
#define NZBGET_CRYPTOREAD_H
#include <stddef.h>
#include <stdint.h>
#ifdef __cplusplus
extern "C" {
#endif
/* Uninitialized owned capacity. Initialize through the archive source before
 * native decryption; only publish plaintext after full success. */
typedef struct NzbgetRsReadInnerScratch {
    uint8_t* data;
    size_t capacity;
} NzbgetRsReadInnerScratch;
/* Null/zero on no allocation or allocation failure; caller retains C++ fallback. */
NzbgetRsReadInnerScratch nzbget_rs_read_inner_scratch_new(size_t bytes);
/* Free only the exact returned handle, once; storage need not be initialized. */
void nzbget_rs_read_inner_scratch_free(NzbgetRsReadInnerScratch scratch);
#ifdef __cplusplus
}
#endif
#endif
