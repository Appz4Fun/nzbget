//! Scratch ownership for the encrypted archive read caller.

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn writable_owned_capacity_is_released_without_reading_unwritten_bytes() {
        let scratch = allocate(8192);
        assert!(!scratch.data.is_null());
        assert!(scratch.capacity >= 8192);
        unsafe {
            scratch.data.write(0xa5);
            scratch.data.add(8191).write(0x5a);
            assert_eq!(scratch.data.read(), 0xa5);
            assert_eq!(scratch.data.add(8191).read(), 0x5a);
            release(scratch);
        }
    }

    #[test]
    fn empty_and_unrepresentable_requests_have_no_owner() {
        for bytes in [0, usize::MAX] {
            let scratch = allocate(bytes);
            assert!(scratch.data.is_null());
            assert_eq!(scratch.capacity, 0);
            unsafe { release(scratch) };
        }
    }
}

#[repr(C)]
pub struct Scratch {
    pub data: *mut u8,
    pub capacity: usize,
}

/// Returns uninitialized capacity. Rust never gives this storage a length or
/// reads it; C++ owns initialization, native decryption, and success-only copy.
/// Allocation failure leaves no owner so the caller can use its C++ fallback.
pub fn allocate(bytes: usize) -> Scratch {
    let empty = Scratch {
        data: std::ptr::null_mut(),
        capacity: 0,
    };
    if bytes == 0 {
        return empty;
    }
    let mut storage = Vec::<std::mem::MaybeUninit<u8>>::new();
    if storage.try_reserve_exact(bytes).is_err() {
        return empty;
    }
    let scratch = Scratch {
        data: storage.as_mut_ptr().cast(),
        capacity: storage.capacity(),
    };
    std::mem::forget(storage);
    scratch
}

/// # Safety
/// Only an unmodified handle returned by allocate may be released, once.
pub unsafe fn release(scratch: Scratch) {
    if scratch.data.is_null() || scratch.capacity == 0 {
        return;
    }
    drop(Vec::<std::mem::MaybeUninit<u8>>::from_raw_parts(
        scratch.data.cast(),
        0,
        scratch.capacity,
    ));
}

/// Uninitialized storage used only by the encrypted archive read caller.
#[no_mangle]
pub extern "C" fn nzbget_rs_read_inner_scratch_new(bytes: usize) -> Scratch {
    allocate(bytes)
}

/// # Safety
/// Release an unmodified handle returned by scratch_new, once; no Rust slices
/// are formed over the possibly partly initialized C++-written storage.
#[no_mangle]
pub unsafe extern "C" fn nzbget_rs_read_inner_scratch_free(scratch: Scratch) {
    release(scratch);
}
