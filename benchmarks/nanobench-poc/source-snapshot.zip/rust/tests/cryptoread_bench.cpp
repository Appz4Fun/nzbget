// Complete ReadDonorInner timing with warm decoded fixture articles, no providers.
#include "nzbget.h"
#include "ContentMap.h"
#include "StreamCrypto.h"
#include "StreamRepair.h"
#include "nzbget_cryptoread.h"
#include <chrono>
#include <iostream>
#include <cstring>
#include <numeric>
#include <sys/resource.h>
#include <ctime>
class DiskState;class DupeCoordinator;class QueueCoordinator;class ServerPool;class StatMeter;class WorkState;class Log;class Options;
DiskState* g_DiskState=nullptr;DupeCoordinator* g_DupeCoordinator=nullptr;QueueCoordinator* g_QueueCoordinator=nullptr;
ServerPool* g_ServerPool=nullptr;StatMeter* g_StatMeter=nullptr;WorkState* g_WorkState=nullptr;Log* g_Log=nullptr;Options* g_Options=nullptr;
char* (*g_EnvironmentVariables)[]=nullptr;
namespace {
using Clock=std::chrono::steady_clock;
constexpr size_t ArticleBytes=1024*1024;
std::vector<std::vector<char>> fixtures;
uint64_t fetches=0,allocs=0,frees=0,live=0;
volatile uint64_t sink;
double lastThreadCpuNs=0;
ArticleFetcher::FetchedArticle localFetch(const char* id) {
 int member=-1,part=-1;if(sscanf(id,"<fixture-%d-%d>",&member,&part)!=2 || member<0 || part<0 || size_t(member)>=fixtures.size())throw std::runtime_error("nonfixture fetch rejected");
 const auto& bytes=fixtures[size_t(member)];size_t offset=size_t(part)*ArticleBytes;if(offset>=bytes.size())throw std::runtime_error("invalid part");
 ArticleFetcher::FetchedArticle out;size_t length=std::min(ArticleBytes,bytes.size()-offset);out.Data.assign(bytes.begin()+offset,bytes.begin()+offset+length);out.Offset=offset;out.FileSize=bytes.size();out.Success=true;fetches++;return out;
}
uint64_t consume(const std::vector<char>& out) {return out.empty()?0:out.size()+uint8(out.front())*17+uint8(out[out.size()/2])*31+uint8(out.back())*43;}
__attribute__((noinline)) double measure(ContentMap& map,DonorSetSources& sources,StreamRange query,size_t iterations,bool fresh) {
 std::vector<char> reused;if(!fresh && !StreamRepairController::ReadDonorInner(map,sources,query,reused))throw std::runtime_error("warm read failed");
 uint64_t sum=0;timespec cpuStart{},cpuEnd{};auto start=Clock::now();clock_gettime(CLOCK_THREAD_CPUTIME_ID,&cpuStart);
 for(size_t i=0;i<iterations;i++) {
  if(fresh) {std::vector<char> out;if(!StreamRepairController::ReadDonorInner(map,sources,query,out))throw std::runtime_error("read failed");sum+=consume(out);}
  else {if(!StreamRepairController::ReadDonorInner(map,sources,query,reused))throw std::runtime_error("read failed");sum+=consume(reused);}
 }
 clock_gettime(CLOCK_THREAD_CPUTIME_ID,&cpuEnd);auto end=Clock::now();sink=sum;
 lastThreadCpuNs=(double(cpuEnd.tv_sec-cpuStart.tv_sec)*1e9+double(cpuEnd.tv_nsec-cpuStart.tv_nsec))/iterations;
 return std::chrono::duration<double,std::nano>(end-start).count()/iterations;
}
}
extern "C" ArticleFetcher::FetchedArticle wrapFetch(ArticleFetcher*,const char* id,const std::vector<CString>&) asm("WRAPPED_FETCH_SYMBOL");
extern "C" ArticleFetcher::FetchedArticle wrapFetch(ArticleFetcher*,const char* id,const std::vector<CString>&){return localFetch(id);}
extern "C" NzbgetRsReadInnerScratch realNew(size_t) asm("__real_nzbget_rs_read_inner_scratch_new");
extern "C" void realFree(NzbgetRsReadInnerScratch) asm("__real_nzbget_rs_read_inner_scratch_free");
extern "C" NzbgetRsReadInnerScratch wrapNew(size_t) asm("__wrap_nzbget_rs_read_inner_scratch_new");
extern "C" void wrapFree(NzbgetRsReadInnerScratch) asm("__wrap_nzbget_rs_read_inner_scratch_free");
extern "C" NzbgetRsReadInnerScratch wrapNew(size_t bytes) {
 allocs++;
#ifdef CRYPTOREAD_CPP_CONTROL
 auto data=new(std::nothrow) uint8_t[bytes];NzbgetRsReadInnerScratch scratch{data,data?bytes:0};
#else
 auto scratch=realNew(bytes);
#endif
 if(scratch.data)live++;return scratch;
}
extern "C" void wrapFree(NzbgetRsReadInnerScratch scratch) {
 if(scratch.data){frees++;live--;}
#ifdef CRYPTOREAD_CPP_CONTROL
 delete[] scratch.data;
#else
 realFree(scratch);
#endif
}
int main(int argc,char**argv) {
 try {
  if(argc!=5)return 2;size_t members=std::stoull(argv[1]),size=std::stoull(argv[2]);bool fresh=std::string(argv[3])=="1";std::string shape=argv[4];
  constexpr size_t payloadSize=16*1024*1024;std::vector<char> payload(payloadSize);for(size_t i=0;i<payload.size();i++)payload[i]=char((i*7)%251);
  const uint8 salt[8]={1,2,3,4,5,6,7,8};std::shared_ptr<RarCryptoContext> ctx=RarCryptoContext::MakeRar3("fixture",salt);if(!ctx)throw std::runtime_error("crypto unavailable");
  std::vector<char> cipher(payload.size());if(!ctx->EncryptRange(nullptr,(const uint8*)payload.data(),(uint8*)cipher.data(),cipher.size()/16))throw std::runtime_error("encrypt failed");
  NzbInfo posting;ContentMap map;map.SetInnerSize(payload.size());map.SetInnerName("fixture.mkv");fixtures.reserve(members);
  for(size_t i=0;i<members;i++) {
   size_t from=cipher.size()*i/members+(i?i%7:0),to=cipher.size()*(i+1)/members+(i+1<members?(i+1)%7:0);
   fixtures.emplace_back(cipher.begin()+from,cipher.begin()+to);auto file=std::make_unique<FileInfo>(100000+int(i));file->SetSize(to-from);file->SetNzbInfo(&posting);file->SetFilename("fixture.rar");
   for(size_t part=0;part*ArticleBytes<to-from;part++) {auto article=std::make_unique<ArticleInfo>();article->SetPartNumber(int(part+1));article->SetSize(int(std::min(ArticleBytes,to-from-part*ArticleBytes)));auto id="<fixture-"+std::to_string(i)+"-"+std::to_string(part)+">";article->SetMessageId(id.c_str());file->GetArticles()->push_back(std::move(article));}
   posting.GetFileList()->push_back(std::move(file));map.GetRuns()->push_back({int64(from),int(i),0,int64(to-from)});map.GetRunCryptos()->push_back({ctx,0,int64(to-from)});
  }
  ArticleFetcher fetcher;DonorSetSources sources(fetcher,&posting);std::vector<char> full;
  if(!StreamRepairController::ReadDonorInner(map,sources,{0,int64(payload.size())},full) || full!=payload)throw std::runtime_error("full warm parity failed");
  int64 offset=size==payloadSize?0:shape=="cross"?(members>1?(*map.GetRuns())[1].InnerOffset-7:25):3;
  if(offset+int64(size)>int64(payload.size()))throw std::runtime_error("invalid query");StreamRange query{offset,int64(size)};std::vector<char> verified;
  if(!StreamRepairController::ReadDonorInner(map,sources,query,verified) || verified.size()!=size || (size && memcmp(verified.data(),payload.data()+offset,size)))throw std::runtime_error("query parity failed");
  // Keep each sample long enough to reveal process-to-process drift instead
  // of treating sub-millisecond clock/scheduling noise as a speed result.
  size_t iterations=size>=16*1024*1024?2:size>=1024*1024?64:size>=65531?2048:size>=4096?16384:65536;
  measure(map,sources,query,iterations,fresh);
  fetches=0;allocs=0;frees=0;
  std::cout<<"CHECK "<<consume(verified)<<' '<<offset<<' '<<size<<'\n';
  for(int round=0;round<7;round++){
   auto wall=measure(map,sources,query,iterations,fresh);
   std::cout<<"SAMPLE "<<round<<' '<<wall<<'\n'<<"CPU_SAMPLE "<<round<<' '<<lastThreadCpuNs<<'\n';
  }
  if(fetches || live)throw std::runtime_error("warm cache miss or scratch leak");
  std::cout<<"BOUNDARY "<<allocs<<' '<<frees<<' '<<live<<' '<<fetches<<'\n';
 }catch(const std::exception& e){std::cerr<<"FAIL "<<e.what()<<'\n';return 1;}
}
