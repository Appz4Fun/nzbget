// Actual encrypted-read caller checks; provider-free synthetic source boundary.
#include "nzbget.h"
#include "ContentMap.h"
#include "StreamCrypto.h"
#include "RarReader.h"
#include "nzbget_cryptoread.h"
#include <iostream>
#include <stdexcept>
#include <cstring>

namespace {
int allocations=0,releases=0,live=0,nativeCalls=0,inplaceCalls=0;
bool failAllocation=false,failNative=false,throwNative=false;
void require(bool value,const char* text) { if(!value)throw std::runtime_error(text); }
class Bytes : public ContentSource {
public:
 std::vector<char> data;bool fail=false,throwRead=false;int reads=0;
 explicit Bytes(std::vector<char> bytes):data(std::move(bytes)){}
 int64 Size() override{return data.size();}
 bool Read(int64 offset,void* dest,int64 size) override {
  reads++;if(offset<0 || size<0 || offset+size>int64(data.size()))return false;
  auto n=fail || throwRead?std::min<int64>(size,3):size;memcpy(dest,data.data()+offset,size_t(n));
  if(throwRead)throw std::runtime_error("injected source exception after partial write");return !fail;
 }
};
class Sources : public ContentSourceSet {
public:
 std::vector<std::unique_ptr<Bytes>> members;
 ContentSource* GetSource(int index) override{return index>=0 && size_t(index)<members.size()?members[size_t(index)].get():nullptr;}
};
void reset() {allocations=0;releases=0;nativeCalls=0;inplaceCalls=0;failAllocation=false;failNative=false;throwNative=false;require(live==0,"scratch leak before case");}
}
extern "C" NzbgetRsReadInnerScratch realNew(size_t) asm("__real_nzbget_rs_read_inner_scratch_new");
extern "C" void realFree(NzbgetRsReadInnerScratch) asm("__real_nzbget_rs_read_inner_scratch_free");
extern "C" NzbgetRsReadInnerScratch wrapNew(size_t bytes) asm("__wrap_nzbget_rs_read_inner_scratch_new");
extern "C" void wrapFree(NzbgetRsReadInnerScratch) asm("__wrap_nzbget_rs_read_inner_scratch_free");
extern "C" NzbgetRsReadInnerScratch wrapNew(size_t bytes) {
 allocations++;if(failAllocation)return {nullptr,0};auto s=realNew(bytes);if(s.data)live++;return s;
}
extern "C" void wrapFree(NzbgetRsReadInnerScratch s) {if(s.data){live--;releases++;}realFree(s);}
extern "C" bool realDecrypt(const RarCryptoContext*,const uint8*,const uint8*,uint8*,int64) asm("REAL_DECRYPT_SYMBOL");
extern "C" bool wrapDecrypt(const RarCryptoContext*,const uint8*,const uint8*,uint8*,int64) asm("WRAPPED_DECRYPT_SYMBOL");
extern "C" bool wrapDecrypt(const RarCryptoContext* ctx,const uint8* previous,const uint8* input,uint8* output,int64 blocks) {
 nativeCalls++;if(input==output)inplaceCalls++;
 bool ok=realDecrypt(ctx,previous,input,output,blocks);
 if(throwNative)throw std::runtime_error("injected native failure after output write");
 if(failNative){if(blocks>0)output[0]^=1;return false;}
 return ok;
}
void checkCipher(std::shared_ptr<RarCryptoContext> crypto,size_t plainSize=16397) {
  require(bool(crypto),"native crypto unavailable");
  std::vector<char> plain(plainSize);for(size_t i=0;i<plain.size();i++)plain[i]=char((i*7)%251);
  std::vector<char> padded((plain.size()+15)/16*16);memcpy(padded.data(),plain.data(),plain.size());std::vector<char> cipher(padded.size());
  require(crypto->EncryptRange(nullptr,(const uint8*)padded.data(),(uint8*)cipher.data(),cipher.size()/16),"fixture encryption failed");
  Sources sources;ContentMap map;map.SetInnerSize(plain.size());map.SetInnerName("fixture.mkv");
  size_t bases[]={0,2049,6142,cipher.size()};
  for(int i=0;i<3;i++) {
   size_t from=bases[i],to=bases[i+1];sources.members.push_back(std::make_unique<Bytes>(std::vector<char>(cipher.begin()+from,cipher.begin()+to)));
   map.GetRuns()->push_back({int64(from),i,0,int64(std::min(to,plain.size())-from)});map.GetRunCryptos()->push_back({crypto,0,int64(to-from)});
  }
  reset();std::vector<char> out(plain.size()+2,char(0xa5));
  require(map.ReadInnerDecrypted(sources,{0,int64(plain.size())},out.data()+1),"complete read failed");
  require(out.front()==char(0xa5) && out.back()==char(0xa5) && !memcmp(out.data()+1,plain.data(),plain.size()),"complete bytes/canary mismatch");
#ifdef EXPECT_ORIGINAL
  require(allocations==0 && releases==0 && live==0 && nativeCalls==1 && inplaceCalls==0,"original caller boundary mismatch");
#else
  require(allocations==1 && releases==1 && live==0,"active Rust scratch boundary was not used exactly once");
  require(nativeCalls==1 && inplaceCalls==1,"native decrypt was not one in-place call");
#endif
  for(auto query:std::vector<StreamRange>{{3,1},{7,15},{2040,17},{2050,4096},{6141,8193},{int64(plain.size()-4097),4097}}) {
   reset();out.assign(size_t(query.Size)+2,char(0xa5));require(map.ReadInnerDecrypted(sources,query,out.data()+1),"boundary read failed");
   require(out.front()==char(0xa5) && out.back()==char(0xa5) && !memcmp(out.data()+1,plain.data()+query.Offset,size_t(query.Size)),"boundary bytes/canary mismatch");require(live==0,"boundary scratch leak");
#ifndef EXPECT_ORIGINAL
   auto cipherBytes=((query.Offset+query.Size+15)/16-query.Offset/16)*16;
   require(allocations==(cipherBytes>=4096?1:0) && inplaceCalls==allocations,"tiny/normal boundary selection mismatch");
#endif
  }
  reset();out.assign(plain.size(),char(0xa5));auto before=out;sources.members[1]->fail=true;
  require(!map.ReadInnerDecrypted(sources,{0,int64(plain.size())},out.data()) && out==before && nativeCalls==0 && live==0,"partial source failure changed output or leaked");sources.members[1]->fail=false;
  reset();sources.members[1]->throwRead=true;bool sourceCaught=false;
  try{map.ReadInnerDecrypted(sources,{0,int64(plain.size())},out.data());}catch(const std::runtime_error&){sourceCaught=true;}
  require(sourceCaught && out==before && live==0 && nativeCalls==0,"source exception changed output or leaked");sources.members[1]->throwRead=false;
  reset();failNative=true;require(!map.ReadInnerDecrypted(sources,{0,int64(plain.size())},out.data()) && out==before && live==0,"native partial-write failure changed output or leaked");
  reset();throwNative=true;bool caught=false;try{map.ReadInnerDecrypted(sources,{0,int64(plain.size())},out.data());}catch(const std::runtime_error&){caught=true;}
  require(caught && out==before && live==0,"native exception changed output or leaked");
  reset();failAllocation=true;require(map.ReadInnerDecrypted(sources,{0,int64(plain.size())},out.data()),"allocation failure did not use C++ fallback");require(out==plain && live==0 && inplaceCalls==0,"C++ allocation fallback mismatch");
  reset();out.assign(16,char(0xa5));before=out;
  require(!map.ReadInnerDecrypted(sources,{-1,16},out.data()) && out==before,"negative request output changed");
  require(!map.ReadInnerDecrypted(sources,{int64(plain.size()-8),16},out.data()) && out==before,"past-end request output changed");
  require(map.ReadInnerDecrypted(sources,{0,0},out.data()) && out==before && allocations==0,"empty request behavior changed");
  auto partial=map;partial.ExcludeMember(0);require(!partial.ReadInnerDecrypted(sources,{2064,16},out.data()) && out==before && allocations==0,"missing predecessor accepted or allocated scratch");
}
int main() {
 try {
  const uint8 salt[8]={1,2,3,4,5,6,7,8};
  std::shared_ptr<RarCryptoContext> rar3=RarCryptoContext::MakeRar3("fixture",salt);
  checkCipher(rar3);checkCipher(rar3,2*1024*1024+13);
  RarFile::Rar5Crypt rar5;rar5.KdfCount=6;
  for(int i=0;i<16;i++){rar5.Salt[i]=uint8(i+1);rar5.Iv[i]=uint8(31-i);}
  std::shared_ptr<RarCryptoContext> rar5Context=RarCryptoContext::MakeRar5("fixture",rar5);
  checkCipher(rar5Context);checkCipher(rar5Context,2*1024*1024+13);
#ifdef EXPECT_ORIGINAL
  std::cout<<"PASS RAR3/RAR5 original caller failure/partial-output oracle\n";
#else
  std::cout<<"PASS RAR3/RAR5 active Rust boundary, exact plaintext/padding/canaries, CBC cuts, partial source/native failure, source/native exception cleanup, allocation fallback\n";
#endif
 }catch(const std::exception& e){std::cerr<<"FAIL "<<e.what()<<'\n';return 1;}
}
