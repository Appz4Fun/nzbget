#!/usr/bin/env python3
"""Compile actual caller checks and ownership-matched controls offline."""
import argparse
import hashlib
import json
from pathlib import Path
import shlex
import subprocess
import random
import tempfile

ROOT=Path(__file__).resolve().parents[2]
BUILD=ROOT/'build-range'
WORK=BUILD/'cryptoread-compare'
BASE='cd9d4db450be61422421f7a83633d13aadc14d46'
LOCK=Path(tempfile.gettempdir())/'nzbget-rust-benchmark.lock'


def pin(obj, fragment, section):
    symbols=subprocess.check_output(['objdump','-t','-C',str(obj)],text=True)
    matches=[]
    for line in symbols.splitlines():
        fields=line.split(None,5)
        if len(fields)==6 and fragment in fields[5] and fields[3].startswith('.text') and not fields[3].startswith('.text.unlikely'):
            matches.append(fields[3])
    assert len(set(matches))==1, (obj.name,fragment,matches)
    run(['objcopy','--rename-section',matches[0]+'='+section,str(obj)])

def run(argv,**kwargs):return subprocess.run(argv,cwd=ROOT,check=True,**kwargs)

def compile_context():
    entry=next(c for c in json.loads((BUILD/'compile_commands.json').read_text()) if c['file'].endswith('/daemon/postprocess/ContentMap.cpp'))
    raw=shlex.split(entry['command']);flags=[];i=1
    while i<len(raw):
        word=raw[i]
        if word in ['-o','-include']:i+=2;continue
        if word=='-c' or word==entry['file']:i+=1;continue
        flags.append(word);i+=1
    link=shlex.split((BUILD/'CMakeFiles/nzbget.dir/link.txt').read_text());libs=link[link.index('-o')+2:]
    libs=[str(BUILD/x) if not x.startswith('-') and not Path(x).is_absolute() else x for x in libs]
    # This isolated caller suite builds its own current-source Rust archive.
    libs=[str(ROOT/'rust/target/release/libnzbget_rs.a') if x.endswith('/libnzbget_rs.a') else x for x in libs]
    symbol=None
    for item in libs:
        if not item.endswith('.a'):continue
        for line in subprocess.check_output(['nm','-g',item],text=True,stderr=subprocess.DEVNULL).splitlines():
            fields=line.split()
            if len(fields)>=3 and fields[-2]=='T' and 'RarCryptoContext12DecryptRangeE' in fields[-1]:symbol=fields[-1]
    assert symbol
    return raw[0],flags,libs,symbol


def capture_original():
    original=WORK/'original.cpp'
    content=subprocess.check_output(['git','show',BASE+':daemon/postprocess/ContentMap.cpp'])
    if original.exists():assert original.read_bytes()==content
    else:original.write_bytes(content)
    return original


def build(sanitized=False):
    WORK.mkdir(exist_ok=True)
    compiler,flags,libs,symbol=compile_context()
    source=(ROOT/'rust/tests/cryptoread_caller.cpp').read_text().replace('REAL_DECRYPT_SYMBOL','__real_'+symbol).replace('WRAPPED_DECRYPT_SYMBOL','__wrap_'+symbol)
    (WORK/'caller.cpp').write_text(source)
    original=capture_original()
    instrument=['-fsanitize=address,undefined','-fno-omit-frame-pointer'] if sanitized else []
    wraps=['nzbget_rs_read_inner_scratch_new','nzbget_rs_read_inner_scratch_free',symbol]
    for variant in ['original','rust']:
        extra=['-DEXPECT_ORIGINAL'] if variant=='original' else []
        run([compiler,*flags,*instrument,*extra,'-I'+str(ROOT/'rust/include'),'-c',str(WORK/'caller.cpp'),'-o',str(WORK/(variant+'-caller.o'))])
        map_source=original if variant=='original' else ROOT/'daemon/postprocess/ContentMap.cpp'
        run([compiler,*flags,*instrument,'-I'+str(ROOT/'daemon/postprocess'),'-c',str(map_source),'-o',str(WORK/(variant+'-caller-map.o'))])
        exe=WORK/('caller-'+variant+('-sanitized' if sanitized else ''))
        run([compiler,'-O3','-DNDEBUG',*instrument,'-Wl,--gc-sections',*['-Wl,--wrap='+w for w in wraps],str(WORK/(variant+'-caller.o')),str(WORK/(variant+'-caller-map.o')),*libs,'-o',str(exe)])
    paths=[WORK/('caller-'+v+('-sanitized' if sanitized else '')) for v in ['original','rust']]
    paths += [original,WORK/'caller.cpp',ROOT/'daemon/postprocess/ContentMap.cpp',ROOT/'rust/src/cryptoread.rs',ROOT/'rust/include/nzbget_cryptoread.h',ROOT/'rust/src/lib.rs',ROOT/'rust/target/release/libnzbget_rs.a']
    hashes={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
    (WORK/('sanitized-manifest.json' if sanitized else 'manifest.json')).write_text(json.dumps({'base':BASE,'sha256':hashes,'rust_macro':any(v=='-DNZBGET_USE_RUST' for v in flags),'pch':'excluded; same translation-unit boundaries'},indent=2)+'\n')
    print('Built actual Rust-enabled caller checks')


def benchmark_build():
    WORK.mkdir(exist_ok=True)
    compiler,flags,libs,_=compile_context()
    symbols=subprocess.check_output(['nm','-g',str(BUILD/'liblibnzbget.a')],text=True,stderr=subprocess.DEVNULL).splitlines()
    fetch=next(line.split()[-1] for line in symbols if ' T ' in line and 'ArticleFetcher5FetchE' in line)
    fixture=(ROOT/'rust/tests/cryptoread_bench.cpp').read_text().replace('WRAPPED_FETCH_SYMBOL','__wrap_'+fetch)
    (WORK/'bench.cpp').write_text(fixture)
    original=capture_original()
    wraps=[fetch,'nzbget_rs_read_inner_scratch_new','nzbget_rs_read_inner_scratch_free']
    placement=['-no-pie','-Wl,--section-start=.control_read=0x2000000','-Wl,--section-start=.control_measure=0x2020000']
    for variant in ['original','cpp','rust']:
        source=original if variant=='original' else ROOT/'daemon/postprocess/ContentMap.cpp'
        run([compiler,*flags,'-I'+str(ROOT/'daemon/postprocess'),'-c',str(source),'-o',str(WORK/(variant+'-map.o'))])
        pin(WORK/(variant+'-map.o'),'ContentMap::ReadInnerDecrypted(','.control_read')
        extra=['-DCRYPTOREAD_CPP_CONTROL'] if variant=='cpp' else []
        run([compiler,*flags,*extra,'-I'+str(ROOT/'rust/include'),'-c',str(WORK/'bench.cpp'),'-o',str(WORK/(variant+'-bench.o'))])
        pin(WORK/(variant+'-bench.o'),'measure(ContentMap&', '.control_measure')
        run([compiler,'-O3','-DNDEBUG',*placement,'-Wl,--gc-sections',*['-Wl,--wrap='+w for w in wraps],str(WORK/(variant+'-bench.o')),str(WORK/(variant+'-map.o')),*libs,'-o',str(WORK/('bench-'+variant))])
    marker=WORK/'marker.cpp';marker.write_text('extern "C" void artifact_marker(){asm volatile(".rept 8192; nop; .endr");}\n')
    run([compiler,'-O3','-ffunction-sections','-c',str(marker),'-o',str(WORK/'marker.o')])
    run([compiler,'-O3','-DNDEBUG',*placement,'-Wl,--gc-sections','-Wl,--undefined=artifact_marker',*['-Wl,--wrap='+w for w in wraps],str(WORK/'marker.o'),str(WORK/'original-bench.o'),str(WORK/'original-map.o'),*libs,'-o',str(WORK/'bench-perturbed')])
    paths=[original,WORK/'bench.cpp',ROOT/'daemon/postprocess/ContentMap.cpp',ROOT/'rust/src/cryptoread.rs',ROOT/'rust/tests/cryptoread_compare.py']
    paths += [WORK/('bench-'+v) for v in ['original','cpp','rust','perturbed']]
    paths += [Path(p) for p in libs if not p.startswith('-') and Path(p).is_file()]
    hashes={str(p.relative_to(ROOT)) if p.is_relative_to(ROOT) else p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
    (WORK/'benchmark-manifest.json').write_text(json.dumps({'base':BASE,'sha256':hashes,'rust_macro':'-DNZBGET_USE_RUST' in flags,'pch':'excluded for every variant','placement':placement,'flags':[f for f in flags if f.startswith(('-D','-O','-f','-m','-std='))],'boundary':'complete StreamRepairController::ReadDonorInner; warmed fixture article cache; KDF excluded'},indent=2)+'\n')
    print('Built three immutable complete-caller variants')


def benchmark_run(smoke=False, audit=False):
    cases=[(m,n,f,'start') for m in [1,64] for n in [0,1,17,4096,65531,1048576,16777216] for f in [0,1]]
    cases += [(m,65531,f,'cross') for m in [1,64] for f in [0,1]]
    if smoke:cases=[(64,17,0,'start'),(64,65531,0,'cross'),(64,16777216,1,'start')]
    if audit:cases=[(1,17,0,'start'),(64,4096,1,'start'),(64,16777216,1,'start')]
    raw=[];target=WORK/('audit-samples.json' if audit else 'smoke-samples.json' if smoke else 'benchmark-samples.json')
    manifest=json.loads((WORK/'benchmark-manifest.json').read_text())
    for variant in ['original','cpp','rust','perturbed']:
        path=WORK/('bench-'+variant)
        assert hashlib.sha256(path.read_bytes()).hexdigest()==manifest['sha256'][str(path.relative_to(ROOT))]
    for trial in range(1 if smoke else 5 if audit else 3):
        for case in cases:
            variants=['original','perturbed'] if audit else ['original','cpp','rust'];random.Random(str((trial,case))).shuffle(variants)
            for variant in variants:
                output=subprocess.check_output(['flock','-w','120','-x',str(LOCK),'taskset','-c','11',str(WORK/('bench-'+variant)),*map(str,case)],text=True,cwd=ROOT)
                samples=[float(line.split()[2]) for line in output.splitlines() if line.startswith('SAMPLE ')]
                cpu=[float(line.split()[2]) for line in output.splitlines() if line.startswith('CPU_SAMPLE ')]
                boundary=next(line.split()[1:] for line in output.splitlines() if line.startswith('BOUNDARY '))
                allocs,frees,live,fetches=map(int,boundary)
                assert len(samples)==7 and len(cpu)==7 and not live and not fetches and allocs==frees
                assert (allocs>0)==(variant in ['cpp','rust'] and case[1]>=4096)
                raw.append({'trial':trial,'case':case,'variant':variant,'ns':samples,'thread_cpu_ns':cpu,'stdout':output})
                target.write_text(json.dumps(raw,indent=2)+'\n')
            print('Completed',trial,*case,flush=True)
    print('Saved raw complete-caller samples; no acceptance inferred')


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('mode',choices=['build','check','sanitized-build','sanitized-check','benchmark-build','benchmark-run','smoke','audit']);args=parser.parse_args()
    if args.mode=='build':build()
    elif args.mode=='sanitized-build':build(True)
    elif args.mode in ['check','sanitized-check']:
        for variant in ['original','rust']:run([str(WORK/('caller-'+variant+('-sanitized' if args.mode=='sanitized-check' else '')))])
    elif args.mode=='benchmark-build':benchmark_build()
    else:benchmark_run(args.mode=='smoke',args.mode=='audit')
