// Complete ReadDonorInner timing with warm decoded fixture articles, no providers.
#include "nzbget.h"
#include "ContentMap.h"
#include "StreamCrypto.h"
#include "StreamRepair.h"
#include "nzbget_cryptoread.h"
#include <chrono>
#include <iostream>
#include <cstring>
#include <numeric>
#include <sys/resource.h>
#include <ctime>
#define ANKERL_NANOBENCH_IMPLEMENT
#include "nanobench.h"
#include <iomanip>
class DiskState;class DupeCoordinator;class QueueCoordinator;class ServerPool;class StatMeter;class WorkState;class Log;class Options;
DiskState* g_DiskState=nullptr;DupeCoordinator* g_DupeCoordinator=nullptr;QueueCoordinator* g_QueueCoordinator=nullptr;
ServerPool* g_ServerPool=nullptr;StatMeter* g_StatMeter=nullptr;WorkState* g_WorkState=nullptr;Log* g_Log=nullptr;Options* g_Options=nullptr;
char* (*g_EnvironmentVariables)[]=nullptr;
namespace {
using Clock=std::chrono::steady_clock;
constexpr size_t ArticleBytes=1024*1024;
std::vector<std::vector<char>> fixtures;
uint64_t fetches=0,allocs=0,frees=0,live=0;
volatile uint64_t sink;
enum Backend { Original=0, Cpp=1, Rust=2, OriginalControl=3 };
Backend backend=Original;
uint64_t routes[4]={};
bool brokenRoute=false;
ArticleFetcher::FetchedArticle localFetch(const char* id) {
 int member=-1,part=-1;if(sscanf(id,"<fixture-%d-%d>",&member,&part)!=2 || member<0 || part<0 || size_t(member)>=fixtures.size())throw std::runtime_error("nonfixture fetch rejected");
 const auto& bytes=fixtures[size_t(member)];size_t offset=size_t(part)*ArticleBytes;if(offset>=bytes.size())throw std::runtime_error("invalid part");
 ArticleFetcher::FetchedArticle out;size_t length=std::min(ArticleBytes,bytes.size()-offset);out.Data.assign(bytes.begin()+offset,bytes.begin()+offset+length);out.Offset=offset;out.FileSize=bytes.size();out.Success=true;fetches++;return out;
}
uint64_t consume(const std::vector<char>& out) {return out.empty()?0:out.size()+uint8(out.front())*17+uint8(out[out.size()/2])*31+uint8(out.back())*43;}

}
extern "C" ArticleFetcher::FetchedArticle wrapFetch(ArticleFetcher*,const char* id,const std::vector<CString>&) asm("__wrap__ZN14ArticleFetcher5FetchEPKcRKSt6vectorI7CStringSaIS3_EE");
extern "C" ArticleFetcher::FetchedArticle wrapFetch(ArticleFetcher*,const char* id,const std::vector<CString>&){return localFetch(id);}
extern "C" NzbgetRsReadInnerScratch realNew(size_t) asm("__real_nzbget_rs_read_inner_scratch_new");
extern "C" void realFree(NzbgetRsReadInnerScratch) asm("__real_nzbget_rs_read_inner_scratch_free");
extern "C" NzbgetRsReadInnerScratch wrapNew(size_t) asm("__wrap_nzbget_rs_read_inner_scratch_new");
extern "C" void wrapFree(NzbgetRsReadInnerScratch) asm("__wrap_nzbget_rs_read_inner_scratch_free");
extern "C" NzbgetRsReadInnerScratch wrapNew(size_t bytes) {
 allocs++;
NzbgetRsReadInnerScratch scratch{};
 if(backend==Cpp){auto data=new(std::nothrow) uint8_t[bytes];scratch={data,data?bytes:0};}
 else scratch=realNew(bytes);
 if(scratch.data)live++;return scratch;
}
extern "C" void wrapFree(NzbgetRsReadInnerScratch scratch) {
 if(scratch.data){frees++;live--;}
if(backend==Cpp)delete[] scratch.data;else realFree(scratch);
}
extern "C" bool originalRead(const ContentMap*,ContentSourceSet&,const StreamRange&,char*) asm("__real__ZNK10ContentMap18ReadInnerDecryptedER16ContentSourceSetRK11StreamRangePc");
extern "C" bool candidateRead(const ContentMap*,ContentSourceSet&,const StreamRange&,char*) asm("nzbget_fixture_candidate_read");
extern "C" bool wrappedRead(const ContentMap*,ContentSourceSet&,const StreamRange&,char*) asm("__wrap__ZNK10ContentMap18ReadInnerDecryptedER16ContentSourceSetRK11StreamRangePc");
extern "C" bool wrappedRead(const ContentMap* map,ContentSourceSet& sources,const StreamRange& range,char* out) {
 routes[backend]++;
 if(!brokenRoute && (backend==Cpp || backend==Rust))return candidateRead(map,sources,range,out);
 return originalRead(map,sources,range,out);
}
int main(int argc,char**argv) {
 try {
  if(argc!=5 && argc!=6)return 2;brokenRoute=argc==6 && std::string(argv[5])=="--broken-route";size_t members=std::stoull(argv[1]),size=std::stoull(argv[2]);bool fresh=std::string(argv[3])=="1";std::string shape=argv[4];
  constexpr size_t payloadSize=16*1024*1024;std::vector<char> payload(payloadSize);uint32_t seed=0x51c0ffee;for(auto& byte:payload){seed^=seed<<13;seed^=seed>>17;seed^=seed<<5;byte=char(seed&255);}
  const uint8 salt[8]={1,2,3,4,5,6,7,8};std::shared_ptr<RarCryptoContext> ctx=RarCryptoContext::MakeRar3("fixture",salt);if(!ctx)throw std::runtime_error("crypto unavailable");
  std::vector<char> cipher(payload.size());if(!ctx->EncryptRange(nullptr,(const uint8*)payload.data(),(uint8*)cipher.data(),cipher.size()/16))throw std::runtime_error("encrypt failed");
  NzbInfo posting;ContentMap map;map.SetInnerSize(payload.size());map.SetInnerName("fixture.mkv");fixtures.reserve(members);
  for(size_t i=0;i<members;i++) {
   size_t from=cipher.size()*i/members+(i?i%7:0),to=cipher.size()*(i+1)/members+(i+1<members?(i+1)%7:0);
   fixtures.emplace_back(cipher.begin()+from,cipher.begin()+to);auto file=std::make_unique<FileInfo>(100000+int(i));file->SetSize(to-from);file->SetNzbInfo(&posting);file->SetFilename("fixture.rar");
   for(size_t part=0;part*ArticleBytes<to-from;part++) {auto article=std::make_unique<ArticleInfo>();article->SetPartNumber(int(part+1));article->SetSize(int(std::min(ArticleBytes,to-from-part*ArticleBytes)));auto id="<fixture-"+std::to_string(i)+"-"+std::to_string(part)+">";article->SetMessageId(id.c_str());file->GetArticles()->push_back(std::move(article));}
   posting.GetFileList()->push_back(std::move(file));map.GetRuns()->push_back({int64(from),int(i),0,int64(to-from)});map.GetRunCryptos()->push_back({ctx,0,int64(to-from)});
  }
  ArticleFetcher fetcher;DonorSetSources sources(fetcher,&posting);std::vector<char> full;
  if(!StreamRepairController::ReadDonorInner(map,sources,{0,int64(payload.size())},full) || full!=payload)throw std::runtime_error("full warm parity failed");
  int64 offset=size==payloadSize?0:shape=="cross"?(members>1?(*map.GetRuns())[1].InnerOffset-7:25):3;
  if(offset+int64(size)>int64(payload.size()))throw std::runtime_error("invalid query");StreamRange query{offset,int64(size)};std::vector<char> verified;
  if(!StreamRepairController::ReadDonorInner(map,sources,query,verified) || verified.size()!=size || (size && memcmp(verified.data(),payload.data()+offset,size)))throw std::runtime_error("query parity failed");
  const char* names[]={"original","cpp-single-buffer","rust-single-buffer","identical-control"};
  // Mandatory full-output proof and actual boundary hit checks before timing.
  for(int kind=0;kind<4;kind++) {
   backend=Backend(kind);allocs=frees=fetches=0;uint64_t beforeRoutes=routes[kind];
   std::vector<char> check;
   if(!StreamRepairController::ReadDonorInner(map,sources,query,check) || check.size()!=size || (size && memcmp(check.data(),payload.data()+offset,size)))throw std::runtime_error("preflight byte parity failed");
   bool scratchExpected=(kind==Cpp || kind==Rust) && size>=4096;
   if(routes[kind]!=beforeRoutes+1 || (allocs>0)!=scratchExpected || allocs!=frees || live || fetches)throw std::runtime_error("preflight active caller or allocation boundary failed");
   std::cout<<"PREFLIGHT "<<names[kind]<<' '<<allocs<<' '<<frees<<' '<<routes[kind]-beforeRoutes<<'\n';
  }
  std::vector<char> outputs[4];
  for(int kind=0;kind<4;kind++){backend=Backend(kind);if(!StreamRepairController::ReadDonorInner(map,sources,query,outputs[kind]))throw std::runtime_error("prewarm failed");}
  auto operation=[&](Backend selected){
   backend=selected;
   if(fresh){std::vector<char> out;if(!StreamRepairController::ReadDonorInner(map,sources,query,out))throw std::runtime_error("timed read failed");ankerl::nanobench::doNotOptimizeAway(consume(out));}
   else {auto& out=outputs[selected];if(!StreamRepairController::ReadDonorInner(map,sources,query,out))throw std::runtime_error("timed read failed");ankerl::nanobench::doNotOptimizeAway(consume(out));}
  };
  fetches=allocs=frees=0;
  using namespace ankerl::nanobench;
  Bench bench;bench.epochs(52).minEpochTime(std::chrono::milliseconds(3)).maxEpochTime(std::chrono::milliseconds(30)).performanceCounters(false).output(nullptr);
  auto comparison=bench.compare(names[0],[&]{operation(Original);},names[1],[&]{operation(Cpp);},names[2],[&]{operation(Rust);},names[3],[&]{operation(OriginalControl);});
  if(fetches || live || allocs!=frees)throw std::runtime_error("timed cache miss or scratch leak");
  std::cout<<std::setprecision(15)<<"ROUNDS "<<comparison.rounds()<<'\n';
  for(size_t kind=0;kind<comparison.size();kind++) {
   const auto& e=comparison[kind];
   std::cout<<"RESULT "<<e.name<<' '<<e.result.median(Result::Measure::elapsed)*1e9<<' '<<e.relative<<' '<<e.relativeLow<<' '<<e.relativeHigh<<' '<<e.tiedRounds<<'\n';
   for(size_t round=0;round<e.result.size();round++)std::cout<<"RAW "<<e.name<<' '<<round<<' '<<e.result.get(round,Result::Measure::elapsed)*1e9<<' '<<e.result.get(round,Result::Measure::iterations)<<'\n';
  }
  std::cout<<"BOUNDARY "<<allocs<<' '<<frees<<' '<<live<<' '<<fetches<<'\n';

 }catch(const std::exception& e){std::cerr<<"FAIL "<<e.what()<<'\n';return 1;}
}
