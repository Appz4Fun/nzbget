#!/usr/bin/env python3
import hashlib,importlib.util,json,subprocess
from pathlib import Path
ROOT=Path.cwd();W=ROOT/'build-range/nanobench-poc'
spec=importlib.util.spec_from_file_location('caller_context',ROOT/'rust/tests/cryptoread_compare.py');ctx=importlib.util.module_from_spec(spec);spec.loader.exec_module(ctx)
cxx,flags,libs,_=ctx.compile_context()
def run(args):subprocess.run(args,cwd=ROOT,check=True)
def definitions(obj):
 out=subprocess.check_output(['nm','--defined-only',str(obj)],text=True,stderr=subprocess.DEVNULL)
 return [line.split()[-1] for line in out.splitlines() if len(line.split())>=3 and line.split()[-2] in ['T','D','B','R']]
original=W/'original.cpp';original.write_bytes(subprocess.check_output(['git','show',ctx.BASE+':daemon/postprocess/ContentMap.cpp']))
for name,source in [('original',original),('candidate',ROOT/'daemon/postprocess/ContentMap.cpp')]:
 obj=W/(name+'.o');run([cxx,*flags,'-I'+str(ROOT/'daemon/postprocess'),'-c',str(source),'-o',str(obj)])
read=next(n for n in definitions(W/'original.o') if 'ReadInnerDecrypted' in n)
fetch_symbols=subprocess.check_output(['nm','-g',str(ctx.BUILD/'liblibnzbget.a')],text=True,stderr=subprocess.DEVNULL).splitlines();fetch=next(s.split()[-1] for s in fetch_symbols if ' T ' in s and 'ArticleFetcher5FetchE' in s)
candidate=W/'candidate.o';others=[s for s in definitions(candidate) if s!=read]
run(['objcopy','--redefine-sym',read+'=nzbget_fixture_candidate_read',*sum((['--weaken-symbol',s] for s in others),[]),str(candidate)])
source=(W/'caller.cpp.in').read_text().replace('REAL_READ_SYMBOL','__real_'+read).replace('WRAPPED_READ_SYMBOL','__wrap_'+read).replace('WRAPPED_FETCH_SYMBOL','__wrap_'+fetch)
(W/'caller.cpp').write_text(source)
run([cxx,*flags,'-I'+str(W),'-I'+str(ROOT/'rust/include'),'-c',str(W/'caller.cpp'),'-o',str(W/'caller.o')])
wraps=[read,fetch,'nzbget_rs_read_inner_scratch_new','nzbget_rs_read_inner_scratch_free']
run([cxx,'-O3','-DNDEBUG','-no-pie','-Wl,--gc-sections',*['-Wl,--wrap='+n for n in wraps],str(W/'caller.o'),str(W/'original.o'),str(W/'candidate.o'),*libs,'-o',str(W/'paired-caller')])
paths=[W/'paired-caller',W/'caller.cpp',W/'caller.cpp.in',W/'nanobench.h',W/'build.py',original,ROOT/'daemon/postprocess/ContentMap.cpp',ROOT/'rust/src/cryptoread.rs']+[Path(x) for x in libs if not x.startswith('-') and Path(x).is_file()]
manifest={'base':ctx.BASE,'framework':'nanobench v4.6.0','boundary':'real ReadDonorInner; runtime routing of ReadInnerDecrypted; candidate dependency definitions weak, original shared definitions strong','status':'prospective proof of concept; production candidate HOLD unchanged','sha256':{str(p.relative_to(ROOT)) if p.is_relative_to(ROOT) else p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}}
(W/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('Built single-process original / equivalent C++ / Rust / identical-control PoC')
