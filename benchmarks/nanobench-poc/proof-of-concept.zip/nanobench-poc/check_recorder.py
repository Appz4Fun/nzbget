from pathlib import Path
import tempfile,types,subprocess,json,datetime
source=Path(__file__).with_name('run.py').read_text();function=source[source.index('def invoke('):source.index('# RED:')]
with tempfile.TemporaryDirectory() as folder:
 root=Path(folder);attempt=root/'attempt';attempt.mkdir();index={'value':0}
 def fake_run(command,**kwargs):
  directory=attempt/('process-%03d'%index['value']);index['value']+=1
  assert (directory/'command.json').exists() and (directory/'stdout.txt').exists() and (directory/'stderr.txt').exists()
  kwargs['stdout'].write('partial output\n' if index['value']==1 else 'malformed output\n' if index['value']==2 else '{"ok":true}\n');kwargs['stdout'].flush()
  kwargs['stderr'].write('deliberate failure\n');kwargs['stderr'].flush()
  return subprocess.CompletedProcess(command,17 if index['value']==1 else 0)
 env={'ROOT':root,'ATTEMPT':attempt,'processIndex':0,'exe':root/'fake-caller','lock':root/'fake-lock','datetime':datetime,'json':json,'subprocess':types.SimpleNamespace(run=fake_run,CompletedProcess=subprocess.CompletedProcess)}
 exec(function,env)
 first=env['invoke']([64,17,0,'start']);assert first.returncode==17
 saved=(attempt/'process-000/stdout.txt').read_bytes()
 try:
  second=env['invoke']([64,17,0,'start']);assert second.returncode==0
  raise ValueError('simulated parser rejection')
 except ValueError:pass
 third=env['invoke']([64,17,0,'start']);assert third.returncode==0 and json.loads(third.stdout)['ok']
 try:attempt.mkdir(exist_ok=False)
 except FileExistsError:pass
 else:raise AssertionError('collision was not rejected')
 assert (attempt/'process-000/stdout.txt').read_bytes()==saved
 for number,code in [(0,17),(1,0),(2,0)]:
  d=attempt/('process-%03d'%number);assert json.loads((d/'exit.json').read_text())['exit_code']==code
  assert (d/'stdout.txt').read_text() and (d/'stderr.txt').read_text()
 print('PASS raw files and command metadata exist before execution; successful, failed and malformed output retained; exclusive directory collision rejected; earlier process preserved')
