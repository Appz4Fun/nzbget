#!/usr/bin/env python3
from pathlib import Path
import hashlib,json,subprocess,tempfile
ROOT=Path.cwd();W=ROOT/'build-range/nanobench-poc'
plan={'rounds':52,'trials':3,'cases':[[64,17,0,'start'],[64,65531,0,'cross'],[64,65531,1,'cross'],[64,16777216,0,'start'],[64,16777216,1,'start'],[1,17,0,'start'],[1,65531,0,'cross']],'control_precision_band':0.02,'meaning':'prospective PoC precision diagnostic only, not production no-regression acceptance','fixture_seed':'0x51c0ffee','native_crypto':'RAR3 AES-128; KDF and ciphertext generation excluded'}
planfile=W/'plan.json'
if planfile.exists():assert json.loads(planfile.read_text())==plan
else:planfile.write_text(json.dumps(plan,indent=2)+'\n')
m=json.loads((W/'manifest.json').read_text());exe=W/'paired-caller'
assert hashlib.sha256(exe.read_bytes()).hexdigest()==m['sha256'][str(exe.relative_to(ROOT))]
lock=Path(tempfile.gettempdir())/'nzbget-rust-benchmark.lock'
def invoke(case,extra=[]):
 return subprocess.run(['flock','-w','120','-x',str(lock),'taskset','-c','11',str(exe),*map(str,case),*extra],text=True,capture_output=True)
# RED: broken runtime routing must be rejected before any timer runs.
red=invoke([64,65531,0,'cross'],['--broken-route']);assert red.returncode==1 and 'preflight active caller' in red.stderr and 'RESULT ' not in red.stdout
(W/'negative-route-check.json').write_text(json.dumps({'exit':red.returncode,'stdout':red.stdout,'stderr':red.stderr},indent=2)+'\n')
print('PASS deliberately broken caller route rejected before timing',flush=True)
records=[]
for trial in range(plan['trials']):
 for case in plan['cases']:
  out=invoke(case)
  if out.returncode:raise RuntimeError('PoC process failed: '+out.stderr)
  entries=[];preflight=[];boundary=None;rounds=None
  for line in out.stdout.splitlines():
   v=line.split()
   if not v:continue
   if v[0]=='PREFLIGHT':preflight.append({'name':v[1],'scratch_allocations':int(v[2]),'scratch_releases':int(v[3]),'actual_caller_entries':int(v[4])})
   elif v[0]=='ROUNDS':rounds=int(v[1])
   elif v[0]=='RESULT':entries.append({'name':v[1],'median_ns':float(v[2]),'speed_ratio':float(v[3]),'speed_low':float(v[4]),'speed_high':float(v[5]),'tied_rounds':int(v[6]),'samples':[]})
   elif v[0]=='RAW':next(e for e in entries if e['name']==v[1])['samples'].append({'round':int(v[2]),'ns':float(v[3]),'iterations':int(float(v[4]))})
   elif v[0]=='BOUNDARY':boundary=list(map(int,v[1:]))
  assert rounds==52 and len(entries)==4 and len(preflight)==4 and boundary[0]==boundary[1] and boundary[2:]==[0,0]
  assert all(len(e['samples'])==52 for e in entries)
  assert len({s['iterations'] for e in entries for s in e['samples']})==1
  control=entries[3];band=plan['control_precision_band']
  control_bounded=control['speed_low']>=1-band and control['speed_high']<=1+band and control['speed_low']<=1<=control['speed_high']
  record={'trial':trial+1,'case':case,'rounds':rounds,'preflight':preflight,'boundary':boundary,'control_bounded':control_bounded,'entries':entries,'stdout':out.stdout,'stderr':out.stderr}
  records.append(record);(W/'results.json').write_text(json.dumps({'plan':plan,'manifest':m,'negative_route_check':'passed','records':records},indent=2)+'\n')
  print('Completed trial',trial+1,'case',case,'identical-control ratio',round(control['speed_ratio'],4),'interval',[round(control['speed_low'],4),round(control['speed_high'],4)],'bounded',control_bounded,flush=True)
print('Prospective PoC complete; no production qualification inferred',flush=True)
