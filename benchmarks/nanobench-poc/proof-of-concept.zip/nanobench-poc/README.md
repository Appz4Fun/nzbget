# Paired real-caller benchmark proof of concept

Prospective experiment, not production qualification. The cryptoread performance hold remains.

## What was built

Pinned nanobench v4.6.0 measures the real `StreamRepairController::ReadDonorInner` caller in one Linux executable. A test-only linker router selects original or candidate `ReadInnerDecrypted`. Original and identical-control callbacks select the same original implementation. Equivalent optimized C++ and Rust use the same candidate method, changing scratch ownership only. Other strong method definitions stay original; candidate definitions are weakened by the build adapter.

The fixture corpus uses seed `0x51c0ffee`, 16 MiB of bytes, RAR3 AES-128, and 1 or 64 archive members. Decoded local article fixtures populate the real donor caches. Provider fetch is wrapped and rejects nonfixture IDs. Timed fetches must be zero. Key derivation and fixture encryption occur outside the timer; fresh output allocation and scratch lifetime occur inside.

Every backend first proves exact output and real caller-entry counts. Normal/large candidate reads must hit scratch allocation and release exactly once. Tiny reads retain the original buffer algorithm. A deliberately broken router failed before timing, proving the guard detects bypassed candidates.

## Fixed experiment

Seven scenarios, three independent process executions each, 52 paired rounds per execution. Nanobench calibrates one iteration count for every alternative and balances their order. No rounds or scenarios were tuned after viewing results. Native timers include a test-router overhead shared by every alternative.

All 21 comparisons and 4,368 timed samples are retained. Fourteen identical controls met the prospective diagnostic: interval includes 1x and is contained within ±2%. This is a control-precision diagnostic, not a production no-regression tolerance. Several large-read controls remain wide; two normal reused-output comparisons resolve a small difference between identical code. Confidence intervals are per process, not pooled across processes. Nanobench's sign-test independence assumptions are not independently established by this prototype.

Normal single-buffer C++ and Rust times are similar. Their common reduction versus original reflects the shared buffer/initialization design; no Rust-specific advantage is established. Large-read outcomes and complete production performance acceptance remain inconclusive.

## Evidence provenance

Attempt 001 completed all 21 invocations successfully. The original recorder retained stdout/stderr after return-code and parsing checks. Those complete captured outputs remain in `results.json`; the original worker attempt directory also preserves individual recovered outputs with explicit post-validation provenance. It did not guarantee raw retention if a subprocess failed or parsing rejected output.

The repaired recorder creates a fresh exclusive attempt directory, writes command metadata and raw files before execution, and records exit status before parsing. Synthetic successful, failed and malformed outputs plus an exclusive-directory collision passed `check_recorder.py`. No second timing suite executed. A failed upload damaged the worker's current recorder copy; its original preserved attempt source remains intact. The worker had zero available storage, so no further worker writes or benchmark admissions followed.

## Files and reproduction

`proof.html` is a standalone viewer with embedded results, scenario/trial selectors, paired intervals, standalone medians and raw rounds. `results.json` contains complete stdout/stderr, preflight checks, source/library hashes, and all samples. `caller.cpp` is the executed driver; `caller.cpp.in` is its symbolic source template. `nanobench.h` is the pinned released header. `build.py` uses compiler/link flags from an existing configured native/Rust offline checkout; it is not a portable clean-checkout build script. `run.py` is the repaired prospective recorder; the original recorder is separately retained.

The build adapter needs GNU objcopy/nm and the existing cryptoread context helper, source candidate and offline native build. All future remote build admissions must follow heavy-exclusive then benchmark-shared lock order, timeout 120 seconds, maximum three jobs. Prebuilt timing processes use benchmark-exclusive only and release per process. Storage and admission must be available first. This PoC assigns no future timing run.

Executed binary SHA256: `65b9e62e26ebba1ac12c06f32bd20ca8bed2893ec30f65519bbb4fa24dceb0da`

Executed driver SHA256: `22acaa8178f24656c8416c5b95f69cfa69d0a7581ecec73ba3d7cdfb40e4c716`

Framework header SHA256: `2cfcdd57044fd0ee11d1be2b5dc545781b05c36049613c0089a73b332afd8c4d`

Framework release: https://github.com/martinus/nanobench/releases/tag/v4.6.0
